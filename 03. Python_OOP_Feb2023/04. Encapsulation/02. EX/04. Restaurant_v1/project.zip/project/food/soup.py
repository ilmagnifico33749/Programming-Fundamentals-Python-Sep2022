from project.food.starter import Starter
# from starter import Starter


class Soup(Starter):
    pass
