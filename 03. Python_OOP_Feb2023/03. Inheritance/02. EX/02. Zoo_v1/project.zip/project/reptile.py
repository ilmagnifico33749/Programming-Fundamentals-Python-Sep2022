from project.animal import Animal
# from animal import Animal

class Reptile(Animal):
    pass

