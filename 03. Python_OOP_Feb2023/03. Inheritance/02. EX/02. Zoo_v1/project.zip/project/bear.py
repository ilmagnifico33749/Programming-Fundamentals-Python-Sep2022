from project.mammal import Mammal
# from mammal import Mammal

class Bear(Mammal):
    pass
