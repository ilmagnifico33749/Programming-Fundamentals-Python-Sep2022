from project.mammal import Mammal
# from mammal import Mammal

class Gorilla(Mammal):
    pass
