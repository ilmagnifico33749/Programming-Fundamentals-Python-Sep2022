from project.reptile import Reptile
# from reptile import Reptile

class Snake(Reptile):
    pass

