from project.car import Car
# from car import Car

class FamilyCar(Car):
    pass

