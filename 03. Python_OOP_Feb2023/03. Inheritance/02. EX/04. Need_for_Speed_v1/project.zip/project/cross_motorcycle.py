from project.motorcycle import Motorcycle
# from motorcycle import Motorcycle


class CrossMotorcycle(Motorcycle):
    pass

