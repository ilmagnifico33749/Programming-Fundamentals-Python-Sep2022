from project.elf import Elf
# from elf import Elf

class MuseElf(Elf):
    pass

