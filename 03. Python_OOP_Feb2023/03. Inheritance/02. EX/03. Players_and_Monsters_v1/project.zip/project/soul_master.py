from project.dark_wizard import DarkWizard
# from dark_wizard import DarkWizard

class Soulmaster(DarkWizard):
    pass

