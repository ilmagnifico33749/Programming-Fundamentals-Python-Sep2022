from project.hero import Hero
# from hero import Hero

class Knight(Hero):
    pass

