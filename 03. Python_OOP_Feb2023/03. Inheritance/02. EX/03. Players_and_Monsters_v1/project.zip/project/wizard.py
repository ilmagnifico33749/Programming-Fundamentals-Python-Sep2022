from project.hero import Hero
# from hero import Hero

class Wizard(Hero):
    pass