from project.hero import Hero
# from hero import Hero

class Elf(Hero):
    pass

