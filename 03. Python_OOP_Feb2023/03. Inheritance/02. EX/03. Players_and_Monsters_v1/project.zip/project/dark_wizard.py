from project.wizard import Wizard
# from wizard import Wizard

class DarkWizard(Wizard):
    pass