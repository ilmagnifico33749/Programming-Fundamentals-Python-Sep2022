from project.knight import Knight
# from knight import Knight

class DarkKnight(Knight):
    pass

