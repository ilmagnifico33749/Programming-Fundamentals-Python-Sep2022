from project.car import Car
# from car import Car

class SportsCar(Car):
    def __init__(self):
        pass
    def race(self):
        return f"racing..."

