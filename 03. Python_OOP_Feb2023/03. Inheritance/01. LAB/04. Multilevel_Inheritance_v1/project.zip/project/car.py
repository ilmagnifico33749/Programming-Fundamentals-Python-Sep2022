from project.vehicle import Vehicle
# from vehicle import Vehicle

class Car(Vehicle):
    def __init__(self):
        pass
    def drive(self):
        return f"driving..."



