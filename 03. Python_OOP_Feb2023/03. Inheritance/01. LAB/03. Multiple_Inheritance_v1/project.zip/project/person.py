
class Person:
    def __init__(self):
        pass

    def sleep(self):
        return f"sleeping..."