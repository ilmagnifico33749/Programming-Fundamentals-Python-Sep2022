from project.person import Person
# from person import Person

class Employee:
    def __init__(self):
        pass

    def get_fired(self):
        return f"fired..."
