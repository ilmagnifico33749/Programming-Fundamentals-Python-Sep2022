class Animal:
    def __init__(self):
        pass

    def eat(self):
        return f"eating..."
