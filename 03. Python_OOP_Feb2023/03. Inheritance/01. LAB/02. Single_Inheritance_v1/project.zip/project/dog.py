from project.animal import Animal
# from animal import Animal

class Dog(Animal):
    def __init__(self):
        pass

    def bark(self):
        return f"barking..."